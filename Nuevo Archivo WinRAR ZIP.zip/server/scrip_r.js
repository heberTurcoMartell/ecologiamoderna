var boton1 = document.getElementById("boton1");
var caja1 = document.getElementsByClassName("caja");
var elemento = document.getElementsByClassName("presionado");
var opcion = 0;
boton1.onclick = function(){
    let presion = document.getElementsByClassName("presionado");
    let botella = document.getElementById("botella");
    if(opcion == 0){
        console.log("ejecutado");
        presion[0].style.animation = "jugar";
        presion[0].style.animationDuration = "15s";
        botella.style.animation = "movbotella";
        botella.style.animationDuration = "10s";
        opcion = 1;
    }else{
        presion[0].style.animation = "";
        presion[0].style.animationDuration = "";
        botella.style.animation = "";
        botella.style.animationDuration = "";
        opcion = 0;
    }
}