var sinup = document.getElementById("signUp");
var sigin = document.getElementById("signIn");
var nameinput = document.getElementById("nameInput");
var title = document.getElementById("title");
class registro_datos{
    constructor(nombre,contrasenia){
        this.nombre_user = nombre;
        this.contra = contrasenia;
    }
    comparacion(nombre,contrasenia) {
        if(this.nombre_user == nombre && this.contra == contrasenia){
            return true;
        }
        return false;
    }
}

const usuarios = [];
usuarios[0] = new registro_datos("jurado","1234");


window.onload = function(){
    sigin.onclick = function(){
        if(sigin.classList[0] == "disable"){
            nameinput.style.maxHeight = "0px";
            title.innerHTML= "INICIAR SECION";
            sigin.classList.remove("disable");
            sinup.classList.add("disable");
            console.log("cambio2");
            sigin.innerHTML = "INGRESAR";
            sinup.innerHTML = "REGISTRO";
        }else{
            let nombres = document.getElementsByTagName("input");
            if(nombres[1].value == "" || nombres[2].value==""){
                alert("COMPLETE TODOS LOS DATOS");
            }else{
                for (let i = 0; i < usuarios.length; i++) {
                    if(usuarios[i].comparacion(nombres[1].value,nombres[2].value)){
                        console.log("ingresando ..");
                        location.href = "http://localhost:3000/";
                        break;
                    }                    
                }
            }

        }
    }
    sinup.onclick = function(){
        if(sinup.classList[0] == "disable"){
            nameinput.style.maxHeight = "50px";
            title.innerHTML= "REGISTRARSE";
            sinup.classList.remove("disable");
            sigin.classList.add("disable");
            console.log("cambio 1");
            sinup.innerHTML = "GUARDAR";
            sigin.innerHTML = "LOGIN";
        }else{
            alert("La opcion para guardar datos aun no esta disponible");
        }
    }

}
