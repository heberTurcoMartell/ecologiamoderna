const express = require('express');
const socketIo = require('socket.io');
const http = require('http');
var path = require('path');

const app = express();

const server = http.createServer(app);
const io = socketIo(server);

io.on('connection',function(socket){
    console.log('nuevo socket conectado');
});

app.get('/',(req, res, next)=>{
    res.sendFile(__dirname+'/recolector.html')
})

//rutas




const SerialPort =require('serialport').SerialPort;
const {DelimiterParser}=require('@serialport/parser-delimiter')

const puerto = new SerialPort(
    {
        path: 'COM5',
        baudRate: 9600
    }
);
const parser =puerto.pipe(new DelimiterParser({delimiter:'\n'}))

puerto.on('open', function(){
    console.log('conexion abierta');
});

parser.on('data',function (data){
    var enc = new TextDecoder();
    var arr= new Uint8Array(data);
    ready=enc.decode(arr)
    console.log(ready);
    io.emit('aduino:data',{
        value: ready.toString()
    });
});
puerto.on('error',function(err){
    console.log(err);
});


server.listen(3000,()=>{
    console.log('server on port', 3000);
});